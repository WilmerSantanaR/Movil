package com.example.ferreteriaapp

data class Producto(val nombre: String, val descripcion: String, val precio: Double)